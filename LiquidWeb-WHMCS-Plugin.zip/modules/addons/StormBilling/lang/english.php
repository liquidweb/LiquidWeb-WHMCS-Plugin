<?php

$LANG['cpanel'] = 'Cpanel';
$LANG['cpanelExtended'] = 'Cpanel Extended';
$LANG['default'] = 'Default';
$LANG['directadmin'] = 'DirectAdmin';
$LANG['directadminExtended'] = 'DirectAdmin Extended';
$LANG['plesk10'] = 'Plesk 10';
$LANG['pleskExtended'] = 'Plesk Extended';
$LANG['rackspaceCloud'] = 'Rackspace Cloud';
$LANG['rackspacedEmail'] = 'Rackspace Email';
$LANG['rackspaceEmailExtended'] = 'Rackspace Email Extended';
$LANG['solusvmpro'] = 'SolusVM Pro';
$LANG['ticketBilling'] = 'Ticket Billing';
$LANG['zimbraEmail'] = 'Zimbra Email';
$LANG['free'] = 'Free';
$LANG['usage_records'] = 'Usage Records';
$LANG['usage_records_pricing'] = 'Pricing For Usage Records';
$LANG['credit_billing'] = 'Credit Billing';
$LANG['current_credit'] = 'Credits Used For This Service';
$LANG['current_paid'] = 'Alredy Paid For This Service';
$LANG['record'] = 'Record';
$LANG['usage'] = 'Usage';
$LANG['total'] = 'Total';
$LANG['resource_deleted'] = 'Resource Deleted';
$LANG['total_for']          = 'Total For';